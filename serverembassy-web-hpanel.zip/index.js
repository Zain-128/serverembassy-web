// Hostinger hPanel Node.js Application Startup File
// You can select either "server.js" or "index.js" as the startup file in hPanel
require('./server.js');
