var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/sitemap/[__metadata_id__]/route.js")
R.c("server/chunks/[root-of-the-server]__1qiss9l._.js")
R.c("server/chunks/[root-of-the-server]__19vy27y._.js")
R.c("server/chunks/_next-internal_server_app_sitemap_[__metadata_id__]_route_actions_0z_sqiv.js")
R.m(83345)
module.exports=R.m(83345).exports
