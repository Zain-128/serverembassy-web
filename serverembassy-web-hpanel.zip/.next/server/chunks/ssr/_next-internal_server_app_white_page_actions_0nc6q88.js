module.exports=[29774,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_white_page_actions_0nc6q88.js.map