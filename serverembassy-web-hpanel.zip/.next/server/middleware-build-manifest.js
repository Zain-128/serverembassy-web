globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/u63BtNpqDNFosTwF4BD0n/_buildManifest.js",
    "static/u63BtNpqDNFosTwF4BD0n/_ssgManifest.js",
    "static/u63BtNpqDNFosTwF4BD0n/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0zq1_hds0g4k8.js",
    "static/chunks/0t69ubdlbeh2j.js",
    "static/chunks/0h8l05q94cj9c.js",
    "static/chunks/2eac3h7pvlden.js",
    "static/chunks/turbopack-12new4sn4usij.js"
  ]
};
